# CS-550 Section 01 Spring 2020 Assignment 02

## Character Device Driver to List Processes

To run, enter the following command:

$ make load  // To make and load the kernel module
$ make run   // To make and run the user program 
